#include "CShape.h"

CShape::CShape(float x, float y) : m_x(x), m_y(y) {}
